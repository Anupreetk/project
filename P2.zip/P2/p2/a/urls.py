from django.urls import path
from .views import *
urlpatterns = [
    path('', home,name="home"),
    path('index/',index,name="index"),
    path('delete_data/<int:id>/',delete_data,name="delete_data"),
    path('update_data/<int:id>/',update_data,name="update_data"),
    path('login/',loginuser,name="login"),
    path('signup/',signup,name="signup"),
    path('logout/',logoutUser,name="logout"),

]
