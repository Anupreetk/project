from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect
from .models import *
from .forms import *
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login,logout,authenticate
# Create your views here.
def home(request):
	stu=s.objects.all()
	form=s_register()
	if request.method=="POST":
		form=s_register(request.POST)
		if form.is_valid():
			name=form.cleaned_data['name']
			email=form.cleaned_data['email']
			pasd=form.cleaned_data['password']
			user=s(name=name,email=email,password=pasd,image=image)
			user.save()
			return render(request,'index.html',{"stu":stu,"form":form})
	return render(request,'index.html',{"stu":stu,"form":form})



def index(request):
	return render(request,'index.html',{})

def delete_data(request,id):
	if request.method=='POST':
		pi=s.objects.get(pk=id)
		pi.delete()
		return HttpResponseRedirect('/')

def update_data(request,id):
	if request.method=='POST':
		pi=s.objects.get(pk=id)
		fm=s_register(request.POST,instance=pi)
		if fm.is_valid():
			fm.save()
	else:
		pi=s.objects.get(pk=id)
		fm=s_register(instance=pi)
	return render(request,'updatestudent.html',{'form':fm})


def loginuser(request):
	if request.user.is_authenticated:
		return redirect('/')
	else:
		if request.method=="POST":
			name=request.POST.get('username')
			pwd=request.POST.get('password')
			user=authenticate(request,username=name,password=pwd)
			if user is not None:
				login(request,user)
				return redirect('/')
	return render(request,'login.html')

def signup(request):
	if request.user.is_authenticated:
		return redirect('/')
	else:
		Form=UserCreationForm()
		if request.method=='POST':
			Form=UserCreationForm(request.POST)
			if Form.is_valid():
				currUser=Form.save()
				return redirect('login')
	return render(request,'signup.html',{"form":Form})

def logoutUser(request):
	logout(request)
	return redirect("login")
